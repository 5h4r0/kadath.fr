'use client'

import { deletePage } from '@/app/actions/cms'
import { useRouter } from 'next/navigation'
import { useTransition } from 'react'

export function DeleteButton({ pageId, locale }: { pageId: string; locale: string }) {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()

  function handleDelete() {
    if (!confirm('Supprimer cette page ? Cette action est irréversible.')) return
    startTransition(async () => {
      await deletePage(pageId)
      router.push(`/${locale}/cms`)
    })
  }

  return (
    <button
      type="button"
      onClick={handleDelete}
      disabled={isPending}
      className="rounded border border-[#3a1a1a] px-4 py-2 text-sm text-[#cf4a4a] hover:bg-[#3a1a1a] disabled:opacity-50"
    >
      {isPending ? 'Suppression…' : 'Supprimer'}
    </button>
  )
}
